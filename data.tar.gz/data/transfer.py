#!/usr/bin/python
#coding:utf-8
import sys
import traceback
reload(sys)
sys.setdefaultencoding('utf-8')
from file_utils import parseEntities
import os

indir = './people/'
ouf = open('./w2v_corpus.txt', 'w')
cnt = 0
for filename in os.listdir(indir):
    if not filename.endswith('txt'):
        continue
    print(filename)
    with open(indir+filename,'r') as inf:
        for line in inf:
            try:
                entities = parseEntities(line.split(' '))
                line = ''
                for ent in entities:
                    if ent.isCompose:
                        for e in ent.sub:
                            line += e.word + ' ' 
                    else:
                        line += ent.word + ' '
                line = line.strip()
                ouf.writelines('%s\n'%line)
            except Exception:
                print(line)
                cnt += 1
print('done')
print('cnt == %d' %cnt)
