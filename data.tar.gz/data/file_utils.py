#!/usr/bin/python
#coding:utf-8
import json
import sys
import re
import traceback
reload(sys)
sys.path.append('../')
sys.setdefaultencoding('utf-8')


punctuations = ['(',')','（','）','《','》','【','】','，','、','？','!','。','；','：']

class Entity:
    def __init__(self):
        self.pos = '' 
        self.word = '' 
        self.sub = [] 
        self.isCompose = False 

def parseToken(t):
    idx = t.find('/')
    if 'http://' in t:
        idx = t.rfind('/')
    if idx < 0:
        raise Exception('format error dont found /:['+t+']')
    word = t[:idx]
    pos = t[idx+1:] 
    entity_pos = None
    isEntityBegin = False
    isEntityEnd = False 
    if word == '' and pos == '':
        raise Exception('null word or role:['+t+']')
    if word == '' and pos == '/w':
        word = '/'
        pos = 'w'
    elif word == '' and pos == 'w':
        word = ' '
    if len(word) > 1 and word[0] == '[' :
        word = word[1:] 
        isEntityBegin = True
    ridx = pos.find(']')
    if ridx >= 0:
        isEntityEnd = True 
        entity_pos = pos[ridx+1:] 
        if entity_pos[0] == '/': 
            entity_pos == entity_pos[1:] 
        pos = pos[:ridx]
    didx = pos.find('/')
    if didx >= 0:
        role1 = pos[:didx]
        role2 = pos[didx+1:]
        if re.match(r'[a-zA-Z]{1,}',role1) and re.match(r'[a-zA-Z]{1,}',role2):
            pos = role1
        elif re.match(r'[a-zA-Z]{1,}',role1):
            pos = role1
        elif re.match(r'[a-zA-Z]{1,}',role2): 
            pos = role2
            word += '/'+role1
    if len(word) > len('中'):
        for c in punctuations:
            if word.startswith(c) or word.endswith(c):
                raise Exception('\"'+word+'\" has punc')
    if  not re.match(r'[a-zA-Z]{1,}',pos): 
        raise Exception('role not right:['+pos+']')
    return (word, pos, entity_pos,isEntityBegin,isEntityEnd)

def parseEstToken(t):
    '''
    手工标注的用于评估的数据,格式如下:
    根据,上海证券交易所|O,、,[深圳,证券,交易所]|O,的,数据,显示,，,
    '''
    idx = t.find('|')
    if idx > 0:
        word = t[:idx]
        pos = t[idx+1:] 
    else:
        word = t
        pos = 'A'
    entity_pos = None
    isEntityBegin = False
    isEntityEnd = False 
    if word == '' and pos == '':
        raise Exception('null word or role:['+t+']')
    if len(word) > 1 and word[0] == '[' :
        word = word[1:] 
        isEntityBegin = True
    if len(word) > 1 and word[-1] == ']' :
        word = word[:-1] 
        isEntityEnd = True
        entity_pos = pos
    if pos == 'O':
        pos = 'nt'
    if entity_pos == 'O':
        entity_pos = 'nt'
    return (word, pos, entity_pos,isEntityBegin,isEntityEnd)

def parseEntities(tokenStrList,EST=False):
    entities = []
    compose_entity = None
    for t in tokenStrList:
        if EST:
            word,pos,entity_pos,isEntityBegin,isEntityEnd = parseEstToken(t)
        else:
            word,pos,entity_pos,isEntityBegin,isEntityEnd = parseToken(t)
        if not word and not pos:
            raise Exception('null word and role:\"'+t+'\"')
        entity = Entity()
        entity.pos = pos 
        entity.word = word
        if isEntityBegin and isEntityEnd:
            raise Exception('single marked as composed:\"'+t+'\"')
        if isEntityBegin:
            compose_entity = Entity()
            compose_entity.isCompose = True
            #compose_entity.sub.append(entity)
        if isEntityEnd:
            compose_entity.pos = entity_pos 
            compose_entity.sub.append(entity)
            entities.append(compose_entity)
            compose_entity = None 
            continue
        if not compose_entity:
            entities.append(entity)
        else:
            compose_entity.sub.append(entity)
    return entities 
def markEntitiesLMNO(entities):
    prev_role = None
    i = 0 
    length = len(entities)
    while i < length:
        if entities[i].isCompose:
            begin = 'A'
            mid = 'A'
            end = 'A'
            if entities[i].pos == 'nt': 
                entities[i].role = 'O' 
                begin = 'E'
                mid = 'F'
                end = 'G'
            else:
                entities[i].role = 'A' 
                if prev_role == 'G':
                    begin = 'N'
                if i < length - 1 and entities[i+1].pos == 'nt':
                    end = 'M'
            entities[i].sub[0].role = begin
            prev_role = begin
            for k in range(1,len(entities[i].sub) -1):
                entities[i].sub[k].role = mid 
            entities[i].sub[-1].role = end
            prev_role = end
        else:
            cur_role = 'A'
            next_role = 'A'
            if i < length - 1 and entities[i+1].pos == 'nt':
                next_role = 'O'
            if entities[i].pos == 'nt':
                cur_role = 'O'
            elif (prev_role == 'O' or prev_role == 'G') and next_role == 'O':
                cur_role = 'L'
            elif next_role == 'O':
                cur_role = 'M'
            elif prev_role == 'O' or prev_role == 'G':
                cur_role = 'N'
            entities[i].role = cur_role 
            prev_role = cur_role 
        i += 1
    return entities
def markEntitiesAEFG(entities):
    prev_role = None
    i = 0 
    length = len(entities)
    while i < length:
        if entities[i].isCompose:
            begin = 'A'
            mid = 'A'
            end = 'A'
            if entities[i].pos == 'nt': 
                entities[i].role = 'O' 
                begin = 'E'
                mid = 'F'
                end = 'G'
            else:
                entities[i].role = 'A'
            entities[i].sub[0].role = begin
            prev_role = begin
            for k in range(1,len(entities[i].sub) -1):
                entities[i].sub[k].role = mid 
            entities[i].sub[-1].role = end
            prev_role = end
        else:
            entities[i].role =  'A'
            prev_role =  'A'
        i += 1
    return entities

def testParseEntity():
    content ='在/p １９９８年/t 来临/v 之际/f ，/w 我/r 十分/m 高兴/a 地/u 通过/p [中央/n 人民/n 广播/vn 电台/n]nt 、/w [中国/ns 国际/n 广播/vn 电台/n]nt 和/c [中央/n 电视台/n]nt ，/w 向/p 全国/n 各族/r 人民/n ，/w 向/p [香港/ns 特别/a 行政区/n]ns  同胞/n 、/w 澳门/ns 和/c 台湾/ns 同胞/n 、/w 海外/s 侨胞/n ，/w 向/p 世界/n 各国/r 的/u 朋友/n 们/k ，/w 致以/v 诚挚/a 的/u 问候/vn 和/c 良好/a 的/u 祝愿/vn ！/w'
    tokens = content.split()
    entities = parseEntities(tokens) 
    if len(sys.argv) >= 2 and sys.argv[1] == 'LMNO':
        entities = markEntitiesLMNO(entities) 
    else:
        entities = markEntitiesAEFG(entities) 
    print(content)
    entity = ''
    for ent in entities:
        entity += '('+ent.word+','+ent.role+','+ent.pos+','
        if ent.isCompose:
            entity += 'C:{'
            for e in ent.sub:
                entity+=e.word+'->'+','+e.role+',' +e.pos+','
            entity+='}'
        else: 
            entity += 'S' 
        entity+=')'
    print(entity)

class EstBlock:
    def __init__(self):
        self.path = None
        self.title = None
        self.content = None

def parse_est_block(lines):
    block = EstBlock()
    for line in lines:
        line = line.strip()
        if not line:
            continue
        if line.startswith('path:'):
            block.path = line[5:]
        elif line.startswith('title da split:'): 
            block.title = line[16:-1]
        elif line.startswith('content da split:'):
            block.content = line[18:]
        elif line.startswith('-------'):
            block.content = block.content[:-1]
        else:
            block.content += line
    return block
def load_est_file(filename):
    print('start load estimate files')
    blocks = []
    with open(filename,'r') as f:
        lines = []
        for line in f:
            line = line.strip()
            lines.append(line)
            if line.startswith('--------'):
                blocks.append(parse_est_block(lines))
                lines = []
    return blocks   

